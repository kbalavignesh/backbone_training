
  // js/app.js

  var app = app || {};
  var ENTER_KEY = 13;

	$(function() {
		new app.AppView();
	});
  
	//$( document ).ready(function() {
   // new app.AppView();
	//});