// js/views/todos.js

  var app = app || {};

  app.TodoView = Backbone.View.extend({

    tagName: 'li',

    template: _.template( $('#item-template').html() ),

    events: {
     // 'click .toggle': 'togglecompleted',
     // 'dblclick label': 'edit',
     // 'click .destroy': 'clear',          
     // 'keypress .edit': 'updateOnEnter',
     // 'blur .edit': 'close'
    },

    initialize: function() {
      this.listenTo(this.model, 'change', this.render);
      //this.listenTo(this.model, 'destroy', this.remove);        
    },

    // Re-render the titles of the todo item.
    render: function() {
      this.$el.html( this.template( this.model.attributes ) );
      this.$el.toggleClass( 'done', this.model.get('completed') ); 
      this.$input = this.$('.edit');
      return this;
    },
/*
    // Toggle the `"completed"` state of the model.
    togglecompleted: function() {
      this.model.toggle();
    },

    // Switch this view into `"editing"` mode, displaying the input field.
    edit: function() {
      this.$el.addClass('editing');
      this.$input.focus();
    },

    // Close the `"editing"` mode, saving changes to the todo.
    close: function() {
      var value = this.$input.val().trim();
      if ( value ) {
        this.model.save({ title: value });
      } else {
        this.clear();
      }
      this.$el.removeClass('editing');
    },

    // If you hit `enter`, we're through editing the item.
    updateOnEnter: function( e ) {
      if ( e.which === ENTER_KEY ) {
        this.close();
      }
    },

    clear: function() {
      this.model.destroy();
    }
    */
  });